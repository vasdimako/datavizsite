# Data Visualization Project

The aim was to create a website with multiple pages, scripts and animations centered around a interesting data visualization.

Website Link: <a href="https://vasdimako.github.io/datavizsite/" target="_blank">github-pages</a>
